<?php 
	include_once("includes/header.php"); 
	if($_REQUEST[company_id])
	{
		$SQL="SELECT * FROM company WHERE company_id = $_REQUEST[company_id]";
		$rs=mysql_query($SQL) or die(mysql_error());
		$data=mysql_fetch_assoc($rs);
	}
?> 
	<div class="crumb">
    </div>
    <div class="clear"></div>
	<div id="content_sec">
		<div class="col1">
			<div class="contact">
				<h4 class="heading colr">Add Airlines Company</h4>
				<?php
				if($_REQUEST['msg']) { 
				?>
					<div class="msg"><?=$_REQUEST['msg']?></div>
				<?php
				}
				?>
				<form action="lib/company.php" enctype="multipart/form-data" method="post" name="frm_company">
					<ul class="forms">
						<li class="txt">Name</li>
						<li class="inputfield"><input name="company_name" type="text" class="bar" required value="<?=$data[company_name]?>"/></li>
					</ul>
					<ul class="forms">
						<li class="txt">Photo</li>
						<li class="inputfield"><input name="company_image" type="file" class="bar"/></li>
					</ul>
					<ul class="forms">
						<li class="txt">About Company</li>
						<li class="inputfield">
							<textarea name="company_description" class="bar" required style="height:150px; width:250px;"><?=$data[company_description]?></textarea>
						</li>
					</ul>
					<div class="clear"></div>
					<ul class="forms">
						<li class="txt">&nbsp;</li>
						<li class="textfield"><input type="submit" value="Submit" class="simplebtn"></li>
						<li class="textfield"><input type="reset" value="Reset" class="resetbtn"></li>
					</ul>
					<input type="hidden" name="act" value="save_company">
					<input type="hidden" name="avail_image" value="<?=$data[company_image]?>">
					<input type="hidden" name="company_id" value="<?=$data[company_id]?>">
				</form>
			</div>
		</div>
		<div class="col2">
			<?php if($_REQUEST[company_id]) { ?>
			<div class="contactfinder">
				<h4 class="heading colr">Logo of <?=$data['company_name']?></h4>
				<div><img src="<?=$SERVER_PATH.'uploads/'.$data[company_image]?>" style="width: 250px"></div><br>
			</div> 
			<?php } ?>
			<?php include_once("includes/sidebar.php"); ?> 
		</div>
	</div>
<?php include_once("includes/footer.php"); ?> 
