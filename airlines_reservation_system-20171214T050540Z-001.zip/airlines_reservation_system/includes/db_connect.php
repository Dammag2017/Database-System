<?php
	error_reporting(E_ERROR);
	$db=mysql_connect("localhost","root","dorababu") or die(mysql_error());
	$db_sel=mysql_select_db("airlines_reservation_system") or die(mysql_error());
?>
