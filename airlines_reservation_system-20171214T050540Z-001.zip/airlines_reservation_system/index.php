<?php 
include_once("includes/header.php"); 
include_once("includes/db_connect.php"); 
global $SERVER_PATH;
?>
	
	<div id="banner">
    	<div class="left">        
          <div class="wrapper">
			 <div class="booking-box">
				<?php include_once("booking_box.php"); ?>
            </div>        
            <ul>
               <li><a href="#"><img src="./images/banner2.jpg" alt="" /></a></li>
            </ul>
           
          </div>          
        </div>
    </div>
    <div class="clear"></div>
  <div id="content_sec">
     <div class="col1">
		<h4 class="heading colr">Airlines Reservation System</h4>
			<div class="news">
            <ul>
				<li>
                	<h6 class="last" style="color:#ffffff; font-weight:bold">Family Package to Switzerland</h6>
                    <a href="#" class="thumb"><img src="images/home1.jpg" alt="" style="height:163px; width:266px;"/></a>
                    <p>Europe offers so many opportunities with different cultures, languages, and sights that it can be hard to decide where to go. This is an European Capitals Package, Experience the Visit to the City of Lights Paris, with the Illumination tour and Eiffel Tower, AMSTERDAM,  eclectic city set on the banks of beautiful canals; full of history and diversity) and BRUSSELS (a city blending modern buildings along traditional cobblestone streets, museums and incredible food).</p>
                    <div class="news_links">
                    	<a href="#" class="readmore left">Read More</a>
                    </div>
                </li>
				<li>
                	<h6 class="last" style="color:#ffffff; font-weight:bold">Group tour to Germany</h6>
                    <a href="#" class="thumb"><img src="images/home2.jpg" alt="" style="height:163px; width:266px;"/></a>
                    <p> Experience the Visit to the City of Lights Paris, with the Illumination tour and Eiffel Tower, AMSTERDAM,  eclectic city set on the banks of beautiful canals; full of history and diversity) and BRUSSELS (a city blending modern buildings along traditional cobblestone streets, museums and incredible food). Ability to define Special Event days (days where employees cannot request time-off, are warned or notified on the calendar)</p>
                    <div class="news_links">
                    	<a href="#" class="readmore left">Read More</a>
                    </div>
                </li>
                <li>
                	<h6 class="last" style="color:#ffffff; font-weight:bold">Family package to Paris</h6>
                    <a href="#" class="thumb"><img src="images/home3.jpg" alt="" style="height:163px; width:266px;"/></a>
                    <p>Ability to define Special Event days (days where employees cannot request time-off, are warned or notified on the calendar). Experience the Visit to the City of Lights Paris, with the Illumination tour and Eiffel Tower, AMSTERDAM,  eclectic city set on the banks of beautiful canals; full of history and diversity) and BRUSSELS (a city blending modern buildings along traditional cobblestone streets, museums and incredible food).</p>
                    <div class="news_links">
                    	<a href="#" class="readmore left">Read More</a>
                    </div>
                </li>
                <li>
                	<h6 class="last" style="color:#ffffff; font-weight:bold">Golden Venis Trangel</h6>
                    <a href="#" class="thumb"><img src="images/home4.jpg" alt="" style="height:163px; width:266px;"/></a>
                    <p>Pay Rs. 5,000 per person now and hold the package at this price, payment as per policy can be made in the next 24/48 hrs. Holding of seats are subject to availability and in case of non availability of selected seats you can choose from a wide range of departures. To avail this option, click "Book Now". Ability to define Special Event days (days where employees cannot request time-off, are warned or notified on the calendar)</p>
                    <div class="news_links">
                    	<a href="#" class="readmore left">Read More</a>
                    </div>
                </li>
                <li>
                	<h6 class="last" style="color:#ffffff; font-weight:bold">A Dream Trip to Europe</h6>
                    <a href="#" class="thumb"><img src="images/home5.jpg" alt="" style="height:163px; width:266px;"/></a>
                    <p>Discover the old and new Amsterdam in this City tour by bus and boat! You will see interesting sights and monuments during this tour which highlights the beauty of Amsterdam while our guide gives you an inside of the rich history and culture of this city. There will be a picture stop at a windmill followed by a visit to a diamond factory. You can do the 1 hour canal cruise with a separate open-date ticket, where you will discover more of Amsterdam at your convenience.</p>
                    <div class="news_links">
                    	<a href="#" class="readmore left">Read More</a>
                    </div>
                </li>
			</ul>
			</div>
    </div>
	<div class="col2">
		<div class="contactfinder">
		<h4 class="heading colr">Offer of the Week</h4>
			<ul>
				<li><b>Delhi to London :</b> 600 GBP</li>
				<li><b>Delhi to Franfrut :</b> 550 GBP</li>
				<li><b>Delhi to Germany :</b> 790 GBP</li>
				<li><b>Delhi to Newyork :</b> 350 GBP</li>
				<li><b>Delhi to Wasigton :</b> 850 GBP</li>
				<li><b>Delhi to Phuket :</b> 540 GBP</li>
				<li><b>Delhi to Singapore :</b> 760 GBP</li>
				<li><b>Delhi to Bankog :</b> 730 GBP</li>
				<li><b>Delhi to Venis :</b> 610 GBP</li>
				<li><b>Delhi to Paris City :</b> 670 GBP</li>
			</ul>
		<div><img src="images/save_1.jpg" style="width: 250px"></div>
		<h4 class="heading colr">Get 15% Discount</h4>
		<div><img src="images/save_3.jpg" style="width: 250px"></div>
		</div>
	</div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
</div>
<?php include_once("includes/footer.php"); ?> 
